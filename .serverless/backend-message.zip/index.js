require("dotenv").config({});

const express = require("express");
const cors = require("cors");
const authRouter = require("./router/auth.router");
const templateRouter = require("./router/template.router");
const mongooseConnect = require("./config/db");

// connect to db
mongooseConnect();

const app = express();

// port
const port = process.env.PORT || 5000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// cors
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true,
    optionsSuccessStatus: 200,
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  })
);

// Routes
app.get("/", (req, res) => {
  res.status(200).send("Message server is working fine");
});

// router modules
app.use("/api/user", authRouter);
app.use("/api/message", templateRouter);

// app listen
// app.listen(port, () => {
//   console.log("listen port: " + port);
// });

module.exports = app;
