const mongoose = require("mongoose");

const emailSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  roles: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    default: "",
    required: false,
  },
  isEmailSend: {
    type: Boolean,
    default: false,
  },
});

const emailModel = mongoose.model("email", emailSchema);
module.exports = emailModel;
