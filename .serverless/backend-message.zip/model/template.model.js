const mongoose = require("mongoose");

const templateSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  roles: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  subject: {
    type: String,
    required: false,
  },
  template: {
    type: String,
    required: false,
  },
});

const templateModel = mongoose.model("template", templateSchema);
module.exports = templateModel;
