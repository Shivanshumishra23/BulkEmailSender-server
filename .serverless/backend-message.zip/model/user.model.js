const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  otp: {
    type: String,
    required: false,
  },
  isOtpVerified: {
    type: Boolean,
    default: false,
  },
  roles: {
    type: String,
    enum: ["hr", "marketing", "ceo"],
    default: "hr",
    required: true,
  },

  emails: {
    type: Array,
    default: [],
    required: false,
  },

  template: {
    type: String,
    default: "",
    required: false,
  },
});

const userModels = mongoose.model("User", userSchema);
module.exports = userModels;
