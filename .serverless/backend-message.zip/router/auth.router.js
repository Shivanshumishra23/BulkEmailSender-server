const express = require("express");
const userModels = require("../model/user.model");
const {
  registerUser,
  lognUser,
  forgotUserPassword,
  verifyOTP,
  createNewPassword,
  resetPassword,
} = require("../controller/user.controller");
const { authenticate } = require("../middleware/auth.middleware");
const authRouter = express.Router();

// Register user - Admin handle
authRouter.post("/register", registerUser);

// Login based on rolesresetPassword
authRouter.post("/login", lognUser);

// forgot password
authRouter.post("/forgot", forgotUserPassword);
authRouter.post("/verify-otp", verifyOTP);
authRouter.post("/create-password", createNewPassword);

// authenticate route
authRouter.post("/reset-password", authenticate, resetPassword);

module.exports = authRouter;
