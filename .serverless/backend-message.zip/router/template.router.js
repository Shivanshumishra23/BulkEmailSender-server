const express = require("express");
const { authenticate } = require("../middleware/auth.middleware");
const upload = require("../util/multer");
const {
  uploadFileSendEmail,
  templateHtml,
  templateDepartmentFilter,
  deleteTemplate,
} = require("../controller/template.controller");
const templateRouter = express.Router();

// UPLOAD FILES --------------------------------
templateRouter.post(
  "/files",
  authenticate,
  upload.single("file"),
  uploadFileSendEmail
);

// Add templates --------------------------------
templateRouter.post("/template/add", authenticate, templateHtml);
templateRouter.get(
  "/template/status/:department",
  authenticate,
  templateDepartmentFilter
);
templateRouter.get(
  "/template/delete/:templateId",
  authenticate,
  deleteTemplate
);

module.exports = templateRouter;
