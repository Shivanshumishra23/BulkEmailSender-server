const nodemailer = require("nodemailer");

const userEmail = process.env.email;
const userPassword = process.env.password;

const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth: {
    user: userEmail,
    pass: userPassword,
  },
});

const sendMailToEmail = async (emailList, subject, html) => {
  // Email configuration
  const mailOptions = {
    from: userEmail,
    to: emailList, // Array of email addresses,
    subject: subject,
    html: html,
  };

  // Send email
  await transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });
};

module.exports = sendMailToEmail;
