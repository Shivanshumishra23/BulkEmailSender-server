const multer = require("multer");

// Multer configuration
const storage = multer.memoryStorage(); // Use memory storage to handle the file in memory
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Check if the file extension is xlsx
    if (file.originalname.match(/\.(xlsx)$/)) {
      return cb(null, true);
    }
    return cb(new Error("Only XLSX files are allowed!"));
  },
});

module.exports = upload;
