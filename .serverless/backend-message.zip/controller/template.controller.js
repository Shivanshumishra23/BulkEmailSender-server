const xlsx = require("node-xlsx");
const XLSX = require("xlsx");
const templateModel = require("../model/template.model");
const sendMailToEmail = require("../util/MAILER");
const emailModel = require("../model/email.model");

const html = `
<!DOCTYPE html>
<html>

<head>
    <title>Leave Application</title>
</head>

<body style="font-family: Arial, sans-serif;">

    <p style="margin-bottom: 15px;"><strong>Subject:</strong> Leave Application</p>

    <p style="margin-bottom: 15px;">Dear HR,</p>

    <p style="margin-bottom: 15px;">
        I hope this email finds you well. I am writing to formally request a leave of absence from work due to
        [provide a brief reason for the leave, e.g., personal reasons, family emergency, health issues, etc.].
    </p>

    <p style="margin-bottom: 15px;">
        I plan to start my leave on <strong>[start date]</strong> and return to work on <strong>[return date]</strong>.
        During my absence, I will ensure that all my responsibilities are taken care of, and I am willing to delegate
        tasks or provide necessary information to ensure a smooth workflow in my absence.
    </p>

    <p style="margin-bottom: 15px;">
        If required, I am willing to discuss my workload and responsibilities with <strong>[colleague's name or team]</strong>
        to ensure a seamless transition during my leave.
    </p>

    <p style="margin-bottom: 15px;">
        I understand the importance of proper planning and coordination to minimize any inconvenience to the team and the
        company. I have attached any necessary supporting documents, such as a medical certificate or any other relevant
        information.
    </p>

    <p style="margin-bottom: 15px;">
        I appreciate your understanding and cooperation in this matter. Please let me know if there are any forms or
        procedures I need to follow to formalize this leave request.
    </p>

    <p style="margin-bottom: 15px;">Thank you for your prompt attention to this matter. I look forward to your positive response.</p>

    <p>Sincerely,<br>
        Md Ashif Reza
       
    </p>

</body>

</html>



`;

// Function to check if an email already exists in the database
const isEmailExist = async (req, emailList) => {
  const { _id, roles } = req.user;
  console.log(_id, roles);
  for (const email of emailList) {
    const emailExist = await emailModel.findOne({ email: email, roles: roles });
    if (!emailExist) {
      await saveEmailToDB(_id, roles, email);
    }
  }
};

// Function to save an email to the database
const saveEmailToDB = async (id, roles, email) => {
  await emailModel.create({
    userId: id,
    roles: roles,
    email: email,
    isEmailSend: true,
  });
};

const uploadFileSendEmail = async (req, res, next) => {
  try {
    const { _id } = req.user;
    if (!_id) {
      return res.status(401).json({ message: "Unauthorized user" });
    }
    const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
    const sheetName = workbook.SheetNames[0];
    const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

    /*************-------------------SEND EMAIL AT ONCE ---------------------******************* */
    const emailList = data?.map((email) => email["Email" || "email"]);

    // await sendMailToEmail(emailList, " Leave Application", html);

    await isEmailExist(req, emailList);

    res.json({
      message: "File uploaded and processed successfully",
      data,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

const templateHtml = async (req, res) => {
  try {
    const { id: userId, roles } = req.user;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized user" });
    }
    const { template, subject } = req.body;

    if (!template) {
      return res
        .status(400)
        .json({ message: "Please provide a template name" });
    }

    const savedTemplate = new templateModel({
      userId: userId,
      roles: roles,
      subject: template,
      template: template,
    });

    await savedTemplate.save();

    res.status(200).json({
      message: "File uploaded and processed successfully",
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// filter based on department
const templateDepartmentFilter = async (req, res) => {
  try {
    const { id: userId, roles } = req.user;

    if (!userId || !roles) {
      return res.status(401).json({ message: "Unauthorized user" });
    }

    /******************** Already role is present - we passing  query parameters ******/
    const enumDepartment = ["hr", "marketing", "ceo"];
    const { deparment } = req.params;

    // department must be specified ["hr","marketing","ceo"]
    const isDepartment = enumDepartment.includes(deparment);

    if (!isDepartment) {
      return res.status(403).json({ message: "Department does not matched" });
    }

    // filter all templates based on department
    const template = await templateModel.find({
      userId: userId,
      $or: [{ roles: deparment }, { roles: roles }],
    });

    res
      .status(200)
      .json({ message: "template fetched successfully", data: template });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// delete template from db
const deleteTemplate = async (req, res) => {
  try {
    const { id: userId, roles } = req.user;
    if (!userId || !roles) {
      return res.status(401).json({ message: "Unauthorized user" });
    }
    const { templateId } = req.params;
    if (!templateId) {
      return res.status(203).json({ message: "Template id not found" });
    }
    await templateModel.findOneAndDelete({
      userId: userId,
      roles: roles,
      id: templateId,
    });
    res.status(200).json({ message: "Template deleted successfully " });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  uploadFileSendEmail,
  templateHtml,
  templateDepartmentFilter,
  deleteTemplate,
};
