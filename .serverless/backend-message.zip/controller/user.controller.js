const bcrypt = require("bcryptjs");
const userModels = require("../model/user.model");
const OTP = require("../util/otp");
const sendEmailForgotPassword = require("../util/OTPMAIL");
const { createJWTTOken } = require("../util/JWT");
const SALT = parseInt(process.env.SALT);

const otpStore = {};

// Register user
const registerUser = async (req, res) => {
  try {
    const { email, password, roles } = req.body;
    if (!email || !password | !roles) {
      return res
        .status(403)
        .json({ message: "email and password,roles required fields" });
    }
    if (!req.body.roles) {
      return res.status(403).json({ message: "roles is missing" });
    }

    const emailExist = await userModels.findOne({ email: email, roles: roles });

    if (emailExist) {
      return res
        .status(403)
        .json({ message: `email already exist with  ${roles} roles` });
    }
    // save to db

    const hashPassword = await bcrypt.hash(password, SALT);

    const newUser = new userModels({
      email,
      password: hashPassword,
      roles,
    });
    const user = await newUser.save();
    res.status(201).json({ message: "user created", user });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Login user
const lognUser = async (req, res) => {
  try {
    const { email, password, roles } = req.body;

    if (!email || !password) {
      return res
        .status(403)
        .json({ message: "Please enter your email address and password" });
    }
    if (!req.body.roles) {
      return res.status(403).json({ message: "roles is missing" });
    }
    const user = await userModels.findOne({ email: email, roles: roles });

    if (!user) {
      return res.status(403).json({ message: "User not found" });
    }

    // check password is matched or not
    const bcr = await bcrypt.compare(password, user.password);
    console.log(bcr);
    console.log(user.password);

    console.log(password);
    if (!bcr) {
      return res.status(403).json({ message: "Invalid password" });
    }
    // create jwt token
    const token = await createJWTTOken(user);

    res.status(200).json({ message: "user logged in", user, token: token });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Forgot password
const forgotUserPassword = async (req, res, next) => {
  try {
    const { email, roles } = req.body;

    if (!email) {
      return res.status(403).json({ message: "Email is required" });
    }
    if (!req.body.roles) {
      return res.status(403).json({ message: "roles is missing" });
    }
    const otpDigit = OTP(5);

    const user = await userModels.findOne({ email: email, roles: roles });
    if (!user) {
      return res.status(403).json({ message: "User not found" });
    }

    // Store OTP in memory
    otpStore[email] = otpDigit;

    // save to db
    user.otp = otpDigit;
    user.isOtpVerified = false;
    await user.save();

    // send to email to - EMAIL
    await sendEmailForgotPassword(email, otpDigit);
    res.status(200).json({ message: "OTP sent to your email" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Verify OTP
const verifyOTP = async (req, res) => {
  try {
    const { email, otp, roles } = req.body;
    if (!email) {
      return res.status(403).json({ message: "Email is required" });
    }
    if (!req.body.roles) {
      return res.status(403).json({ message: "roles is missing" });
    }
    const user = await userModels.findOne({ email: email, roles: roles });
    if (!user) {
      return res.status(403).json({ message: "User not found" });
    }

    if (user.otp === otp) {
      user.isOtpVerified = true;
      await user.save();
      res.status(200).send("OTP verification successful.");
    } else {
      res.status(401).send("Invalid OTP. Please try again.");
    }

    // Retrieve stored OTP
    // const storedOTP = otpStore[email];
    // if (otp === storedOTP) {
    //   res.status(200).send("OTP verification successful.");
    //   // Clear OTP after successful verification (optional)
    //   delete otpStore[email];
    // } else {
    //   res.status(401).send("Invalid OTP. Please try again.");
    // }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Create new Password

const createNewPassword = async (req, res) => {
  try {
    const { email, password, confirmPassword, roles } = req.body;
    if (!email) {
      return res.status(403).json({ message: "Email is required" });
    }
    if (password !== confirmPassword) {
      return res.status(403).json({ message: "password does not matched" });
    }

    if (!req.body.roles) {
      return res.status(403).json({ message: "roles is missing" });
    }

    const user = await userModels.findOne({ email: email, roles: roles });
    if (!user) {
      return res.status(403).json({ message: "User not found" });
    }
    if (user.isOtpVerified) {
      const hashPassword = await bcrypt.hash(password, SALT);
      user.password = hashPassword;
      user.isOtpVerified = false;
      await user.save();

      res.status(200).json({
        message: "Password changed successfully ",
      });
    } else {
      return res.status(403).json({ message: "password created already" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

// Reset Password
const resetPassword = async (req, res) => {
  try {
    const { email, roles } = req.user;
    const { password, confirmPassword } = req.body;
    if (password !== confirmPassword) {
      return res.status(403).json({ message: "password does not matched" });
    }
    const user = await userModels.findOne({ email: email, roles: roles });
    if (!user) {
      return res.status(403).json({ message: "User not found" });
    }
    const hashPassword = await bcrypt.hash(this.password, SALT);
    user.password = hashPassword;
    user.isOtpVerified = false;
    await user.save();
    res.status(200).json({
      message: "Password changed successfully ",
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  registerUser,
  lognUser,
  forgotUserPassword,
  verifyOTP,
  createNewPassword,
  resetPassword,
};
